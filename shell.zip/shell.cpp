#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctime>
using namespace std;
string trim(string input)
{
    int i = 0;
    while (i < input.size() && input[i] == ' ')
        i++;
    if (i < input.size())
        input = input.substr(i);
    else
    {
        return "";
    }

    i = input.size() - 1;
    while (i >= 0 && input[i] == ' ')
        i--;
    if (i >= 0)
        input = input.substr(0, i + 1);
    else
        return "";

    return input;
}

vector<string> remove_quotes(vector<string> command)
{
    vector<string> clean_strings;
    size_t foundQuotes;
    for (int i = 0; i < command.size(); i++)
    {
        //find first pair of double quotes
        size_t found_double_quotes = command[i].find("\"");
        //find first pair of single quotes
        size_t found_single_quotes = command[i].find("'");
        //handle double quotes
        if (found_double_quotes != string::npos)
        {
            /*Find instances of quotes. Erase the quotes and push back to vector*/
            size_t start_quotes = command[i].find_first_of("\"");
            size_t end_quotes = command[i].find_first_of("\"", start_quotes + 1);
            command[i].erase(start_quotes, 1);
            command[i].erase(end_quotes - 1, 1);
            clean_strings.push_back(command[i]);
        }
        //handle single quotes
        else if (found_single_quotes != string::npos)
        {
            /*Find instances of single quotes. Erase the quotes and push back to vector*/
            size_t start_quotes = command[i].find_first_of("'");
            size_t end_quotes = command[i].find_first_of("'", start_quotes + 1);
            command[i].erase(start_quotes, 1);
            command[i].erase(end_quotes - 1, 1);
            clean_strings.push_back(command[i]);
        }
        else
        {
            clean_strings.push_back(command[i]);
        }
    }
    return clean_strings;
}

vector<string> split(string line, string separator = " ")
{
    vector<string> result;
    int count = 0;
    bool inQuotes = false;
    while (line.size())
    {
        for (int i = 0; i < line.size(); i++)
        {
            /*Check if index is in quotes, set inQuotes to true*/
            if ((line.at(i) == '"' || line.at(i) == '\'') && !inQuotes)
            {
                inQuotes = true;
            }
            /*Check to see if second pair of quotes is found, set inQuotes to false*/
            else if ((line.at(i) == '"' || line.at(i) == '\'') && inQuotes)
            {
                inQuotes = false;
            }
            if (inQuotes && line.at(i) == separator[0])
            {
                /*If separator is found within quotes, add 128 to make it unreadable*/
                line.at(i) += 128;
            }
        }

        size_t found = line.find(separator);

        if (found == string::npos)
        {
            string lastpart = trim(line);
            if (lastpart.size() > 0)
            {
                result.push_back(lastpart);
            }
            break;
        }
        string segment = trim(line.substr(0, found));
        // cout << "segment: " << segment << endl;
        //cout << "line: " << line << "found: " << found << endl;

        line = line.substr(found + 1);
        //cout << "[" << segment << "]"<< endl;
        // cout << "line at end of while: " << line << endl;
        if (segment.size() != 0)
            result.push_back(segment);

        //cout << line << endl;
    }
    /*Go through result vector and restore unreadable chars to tokens*/
    for (int i = 0; i < result.size(); i++)
    {
        size_t found = result[i].find_first_of(separator[0] + 128);
        while (found != string::npos)
        {
            //restore token
            result[i][found] = separator[0];
            //find another instance of unreadable character
            found = result[i].find_first_of(separator[0] + 128, found + 1);
        }
    }
    return result;
}

char **vec_to_char_array(vector<string> parts)
{
    char **result = new char *[parts.size() + 1]; // add 1 for the NULL at the end
    for (int i = 0; i < parts.size(); i++)
    {
        // allocate a big enough string
        result[i] = new char[parts[i].size() + 1]; // add 1 for the NULL byte
        strcpy(result[i], parts[i].c_str());
    }
    result[parts.size()] = NULL;
    return result;
}
void execute(string command)
{
    vector<string> argstrings = split(command, " "); // split the command into space-separated parts
    //cout << argstrings[0] << " " << argstrings[1] << endl;
    //if(argstrings[0] == "awk"){
    argstrings = remove_quotes(argstrings);
    char **args = vec_to_char_array(argstrings); // convert vec<string> into an array of char*
    execvp(args[0], args);
}

int main()
{
    int status;
    queue<char *> directories;
    int MAX_PATH = 500;
    char dir[MAX_PATH];
    char output_dir[MAX_PATH];
    char login_name[20];
    char pastwd[500];
    int backpid;
    vector<pid_t> pids;
    while (true)
    { // repeat this loop until the user presses Ctrl + C
        /*get from STDIN, e.g., "ls  -la |   grep Jul  | grep . | grep .cpp" */
        // split the command by the "|", which tells you the pipe levels

        /*Collect time*/
        time_t now = time(0);
        char *dt = ctime(&now);

        /*Grab username*/
        FILE *user = popen("whoami", "r");
        fread(login_name, 1, 500, user);
        pclose(user);
        string username = "";
        int i = 0;
        //Put username into string
        while (login_name[i] != '\n')
        {
            username += login_name[i];
            i++;
        }
        //OUTPUT PROMPT
        cout << endl;
        getcwd(output_dir, MAX_PATH);
        cout << "AgShell@";
        cout << username << ": " << output_dir << " ";
        cout << dt;

        int save_stdin = dup(0);
        int save_stdout = dup(1);

        string commandline = "";
        getline(cin, commandline);

        bool ampersand = false;
        
        vector<pid_t>tempPid;
        //Find ampersand
        
        if (commandline.back() == '&')
        {
            commandline.pop_back();
            ampersand = true;
        }

        int j ;
        for (j = 0; j < pids.size(); j++)
        {
            if (waitpid(pids[j], 0, WNOHANG) != 0)
            {
                //wait(0);
                //tempPid.push_back(pids[0]);
                //waitpid(pids[i], 0, WNOHANG);
                pids.erase(pids.begin() + j);
                j--;
            }
        }

        if (commandline.find("jobs") != string::npos){
            for (int i = 0; i < pids.size(); i++)
                cout << pids[i] << endl;
        }
        vector<string> tparts = split(commandline, "|");
        // for each pipe, do the following:

        size_t found_exit = tparts[0].find("exit");
        if (found_exit != string::npos)
        {
            return 0;
        }

        //check if line has cd command
        size_t found_CD = tparts[0].find("cd");
        if (found_CD != string::npos)
        {
            string new_path = "/";
            const char *new_dir;
            char *temp;
            //split cd
            vector<string> ch_dir_vector = split(tparts[0], " ");
            //save old directories
            strcpy(pastwd, dir);
            //get current directories
            getcwd(dir, MAX_PATH);
            if (ch_dir_vector[1][0] == '/')
            {
                chdir(ch_dir_vector[1].c_str());
            }
            if (ch_dir_vector[1] == "..")
            {
                chdir(ch_dir_vector[1].c_str());
            }
            else if(ch_dir_vector[1] == "."){
                continue;
            }
            else if (ch_dir_vector[1] == "-")
            {
                //go back to previous working directory
                printf("%s\n", pastwd);
                chdir(pastwd);
            }
            else
            {
                //handle working directory
                //getcwd()
                new_path += ch_dir_vector[1];
                char cwd[500];
                getcwd(cwd, (sizeof(cwd)));
                strcat(cwd, new_path.c_str());
                new_dir = cwd;
                chdir(new_dir);
            }
        }

        for (int i = 0; i < tparts.size(); i++)
        {
            bool quotes = false;
            // make pipe
            int fd[2];
            pipe(fd);
            int childPID = fork();
            
            
           
            if (!childPID)// = !fork())
            {
                
                // redirect output to the next level
                // unless this is the last level
                if (i < tparts.size() - 1)
                {
                    dup2(fd[1], 1); // redirect STDOUT to fd[1], so that it can write to the other side
                    close(fd[1]);   // STDOUT already points fd[1], which can be closed
                }
                
                size_t found_GT;
                size_t found_LT;

                int fd1; //file descriptor
                int fd2; //file descriptor

                //execute function that can split the command by spaces to
                // find out all the arguments, see the definition

                found_GT = tparts[i].find(">"); //outputting to file writing to file
                found_LT = tparts[i].find("<"); //redirecting input

                vector<string> commands_without_sign;

                //if both signs are found in the string

                if (found_LT != string::npos && found_GT != string::npos)
                {
                    if (found_LT < found_GT)
                    {
                        vector<string> files;
                        commands_without_sign = split(tparts[i], "<"); //redirect input

                        if (commands_without_sign.size() > 1)
                            files = split(commands_without_sign[1], ">");
                        else
                        {
                            files = commands_without_sign;
                        }
                        files = remove_quotes(files);

                        if (files.size() > 1)
                        {
                            fd1 = open(files[0].c_str(), O_CREAT | O_RDONLY);
                            dup2(fd1, 0);
                            fd2 = open(files[1].c_str(), O_CREAT | O_WRONLY | O_TRUNC, S_IRUSR | S_IWUSR);
                            dup2(fd2, 1);
                            tparts[i] = commands_without_sign[0];
                        }
                        else
                        {
                            tparts[i] = files[0];
                        }

                        //execute(commands_without_sign[0]);
                    }
                    else
                    {
                        vector<string> files;
                        commands_without_sign = split(tparts[i], ">"); //redirect output
                        if (commands_without_sign.size() > 1)
                            files = split(commands_without_sign[1], "<");
                        else
                        {
                            files = commands_without_sign;
                        }
                        files = remove_quotes(files);
                        if (files.size() > 1)
                        {
                            fd1 = open(files[0].c_str(), O_CREAT | O_WRONLY | O_TRUNC, S_IRUSR | S_IWUSR);
                            dup2(fd1, 1);
                            fd2 = open(files[1].c_str(), O_CREAT | O_RDONLY);
                            dup2(fd2, 0);
                            tparts[i] = commands_without_sign[0];
                        }
                        else
                        {
                            tparts[i] = files[0];
                        }

                        //execute(commands_without_sign[0]);
                    }
                }
                else if (found_LT < found_GT && found_LT != string::npos)
                { // if LT sign is found first
                    commands_without_sign = split(tparts[i], "<");

                    fd1 = open(commands_without_sign[1].c_str(), O_CREAT | O_RDONLY);
                    dup2(fd1, 0);
                    close(fd1);
                    tparts[i] = commands_without_sign[0];
                }
                else if (found_GT < found_LT && found_GT != string::npos)
                { // if GT sign is found first
                    commands_without_sign = split(tparts[i], ">");
                    fd1 = open(commands_without_sign[1].c_str(), O_CREAT | O_WRONLY | O_TRUNC, S_IRUSR | S_IWUSR);
                    //redirect output to file to the right of the sign
                    dup2(fd1, 1);
                    close(fd1);
                    tparts[i] = commands_without_sign[0];
                }

                if (tparts[0].find("echo") != string::npos)
                {
                    vector<string> onlyOne = tparts;
                    onlyOne = remove_quotes(onlyOne);
                    execute(onlyOne[0]);
                }

                execute(tparts[i]); // this is where you execute
            }
            else
            {
                if (ampersand)
                {
                    cout << "==ADDED PID TO LIST==" << endl;
                    //pids.push_back(getpid();
                    pids.push_back(childPID);
                }
                if(!ampersand && i == tparts.size() - 1)
                {
                    //wait(0);
                    waitpid(childPID,0,0);
                }

                /*if (!ampersand)
                    //wait(0);
                    waitpid(childPID,&status, 0);
                */
                // wait for the child process
                // then do other redirects
                dup2(fd[0], 0);
                close(fd[1]);
            }
        }
        dup2(save_stdin, 0);
        dup2(save_stdout, 1);
    }
}